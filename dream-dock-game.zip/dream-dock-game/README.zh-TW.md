# 夢想碼頭｜小小理財家

Godot 4 專案，提供兩關小學生理財與投資風險概念的遊戲切片。第一版以 Godot 3D 碼頭模型作為場景，繁體中文介面提供鍵盤、滑鼠與觸控友善的大按鈕。

## 開啟

1. 安裝 Godot 4.3 或更新版本。
2. 在 Godot Project Manager 匯入本資料夾的 `project.godot`。
3. 開啟專案後按 F6 或 F5 遊玩。

Blender 5.3 用來建立可編輯場景 `blender/source/dream_dock_environment.blend`，並匯出供 Godot 使用的 `assets/dream_dock_environment.glb`。原始建模腳本位於 `blender/create_dream_dock.py`；`blender/source/.gdignore` 讓 Godot 直接使用 GLB，避免要求每位開發者都設定 Blender 路徑。

## 關卡與計分

- 第 1 關：把 8 枚虛構星幣分配給點心與夢想儲蓄目標；解題取得 KEY 1。
- 第 2 關：比較短期修船目標的穩定方案與波動較大的虛構投資；解題取得 KEY 2。
- 每關顯示個別得分；初次解對為 100 分，重試後仍可通關，最低 60 分。分數不看速度。
- 結尾顯示兩關分數、總分、首輪答對關卡數與完成關卡數。

「首輪答對」和「通關」是遊戲內表現紀錄，並非正式學習成效測驗。星幣、投資方案及報酬均為虛構，不能視為真實金融建議。

## 字型

介面使用隨專案打包的 Noto Sans TC 可變字型，確保 Godot Web 在不同作業系統與瀏覽器都能顯示繁體中文。字型依 SIL Open Font License 1.1 發佈，授權全文見 `assets/fonts/OFL.txt`。

## 資產與風險

場景模型由 Blender Python API 程式化建立，包含燈塔、木棧道、海面、微型旅人、儲蓄罐與光點。所有模型和材質為本專案原創；不使用《小小夢魘》的角色、模型或貼圖。美術方向採用使用者選擇的深海微縮夜景。

模型來源、用途、版本與替換狀態記錄在 `docs/assets.md`。

音效尚未納入切片；目前所有重要提示均以文字與色彩呈現。正式加入音效時需保留靜音／音量控制，且不能讓音效成為唯一提示管道。
