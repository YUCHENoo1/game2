# 需求與追溯

## 已核准範圍

- 使用者核准玩法 D「夢想碼頭」，以及視覺方向 1「深海微縮夜景」。
- 目標對象：小學生；主題：生活理財與投資風險概念。
- 兩關，各一個主要互動謎題；解題才取得該關 KEY。
- 每關顯示分數；結束顯示挑戰進度與策略回饋。
- 優先學習；不以解題速度計分。內容只用虛構星幣，不涉及真實投資產品。

## 需求追溯

| ID | 驗收條件 | 實作位置 |
|---|---|---|
| R1 | 第 1 關讓玩家分配 8 枚星幣，正確配置為 2 枚點心、6 枚儲蓄 | `scripts/main.gd`：`_show_level_one`, `_check_level_one` |
| R2 | 第 2 關比較穩定增加與有損失可能的模擬方案 | `scripts/main.gd`：`_show_level_two`, `_choose_investment` |
| R3 | 關卡答對後才增加 KEY，第二關後顯示出口完成 | `scripts/main.gd`：`_complete_stage`, `_update_score_and_key` |
| R4 | 兩關分別計分，總結畫面顯示各關分數與總分 | `scripts/main.gd`：`stage_scores`, `_show_summary` |
| R5 | 最後呈現首輪表現、通關表現與策略摘要 | `scripts/main.gd`：`_show_summary` |
| R6 | Blender 原創 3D 碼頭資產匯入 Godot | `blender/create_dream_dock.py`, `blender/source/dream_dock_environment.blend`, `assets/dream_dock_environment.glb` |
| R7 | 可用鍵盤焦點、滑鼠或觸控友善按鈕操作 | `scripts/main.gd`：`_add_button` |

## 未完成驗證

- 已在 Godot 4.7.2 專案編輯器載入 `main.tscn`，並成功匯入 Blender 匯出的 GLB。
- 尚未啟動遊戲場景或進行小學生玩家測試；因此沒有實際學習成效證據，成效判讀仍需教師或玩家資料。
