# 資產記錄

| ID / 版本 | 用途 | 創作者與工具 | 來源與授權 | 語言依賴 | 尺寸／規格 | 狀態 |
|---|---|---|---|---|---|---|
| `harbor-environment-v1` | Godot 主場景的 3D 碼頭背景 | 本專案 Blender Python 腳本；Blender 5.3 | 原創程式化網格與材質；無第三方角色、貼圖或音樂 | 無語言依賴 | Blender 場景座標；Godot 1600×900 視窗構圖 | 目前使用；GLB 匯入版 |
| `harbor-environment-source-v1` | 編輯及重新匯出模型 | `blender/create_dream_dock.py` + Blender 5.3 | 本專案原創 .blend 原始檔 | 無語言依賴 | `blender/source/dream_dock_environment.blend` | 主場景源檔；保留 |
| `dream-dock-direction-1` | 已核准的視覺方向參考 | 手工 SVG，Codex | 原創提案；未使用生成圖或《小小夢魘》素材 | 繁體中文介面文案 | 1600×900、16:9 | 參考用；遊戲實際介面由 Godot 控制項繪製 |

音效目前未加入遊戲，因此沒有音效素材或音效授權。關鍵提示同時以文字和視覺介面呈現。
