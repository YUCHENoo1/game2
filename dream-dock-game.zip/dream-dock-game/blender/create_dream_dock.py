"""Create original 3D art for the Dream Dock Godot game."""
from pathlib import Path
import math
import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
ASSETS.mkdir(parents=True, exist_ok=True)
SOURCE = ROOT / "blender" / "source"
SOURCE.mkdir(parents=True, exist_ok=True)


def material(name, color, roughness=0.72, metallic=0.0, emission=None):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1.0)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    if emission:
        emission_color, strength = emission
        if "Emission Color" in bsdf.inputs:
            bsdf.inputs["Emission Color"].default_value = (*emission_color, 1.0)
            bsdf.inputs["Emission Strength"].default_value = strength
        else:
            bsdf.inputs["Emission"].default_value = (*emission_color, 1.0)
    return mat


MAT = {
    "sea": material("Sea · deep slate blue", (0.035, 0.095, 0.16), 0.32, 0.18),
    "dock": material("Dock · weathered midnight wood", (0.11, 0.17, 0.20)),
    "plank": material("Dock planks · warm timber", (0.34, 0.28, 0.21)),
    "tower": material("Lighthouse · blue stone", (0.19, 0.25, 0.29)),
    "trim": material("Lighthouse · aged brass", (0.56, 0.40, 0.19), 0.35, 0.42),
    "glass": material("Lantern glass · glowing amber", (0.95, 0.57, 0.18), 0.25, 0.1, ((1.0, 0.43, 0.1), 2.6)),
    "dark": material("Door and window · deep navy", (0.035, 0.07, 0.10), 0.5),
    "coat": material("Traveler · coral coat", (0.78, 0.25, 0.13), 0.72),
    "cap": material("Traveler · teal cap", (0.09, 0.34, 0.40), 0.8),
    "skin": material("Traveler · warm skin tone", (0.61, 0.34, 0.22)),
    "pack": material("Traveler · little lamp pack", (0.18, 0.24, 0.22)),
    "gold": material("Star coins · soft gold", (0.95, 0.62, 0.18), 0.28, 0.34, ((1.0, 0.42, 0.09), 0.45)),
    "jar": material("Dream jar · muted sage", (0.23, 0.40, 0.34), 0.32, 0.06),
    "wave": material("Distant wave silhouettes", (0.065, 0.12, 0.18), 0.55),
}


def assign(obj, mat):
    obj.data.materials.append(mat)
    return obj


def cube(name, location, dimensions, mat, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = dimensions
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    assign(obj, mat)
    if bevel:
        mod = obj.modifiers.new("Soft rounded miniature edges", "BEVEL")
        mod.width = bevel
        mod.segments = 3
        obj.modifiers.new("Weighted corner normals", "WEIGHTED_NORMAL")
    return obj


def sphere(name, location, scale, mat, segments=16, rings=10):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, radius=1.0, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return assign(obj, mat)


def cylinder(name, location, radius, depth, mat, vertices=16, rotation=None):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=location)
    obj = bpy.context.object
    obj.name = name
    if rotation:
        obj.rotation_euler = rotation
    return assign(obj, mat)


def cone(name, location, radius_bottom, radius_top, depth, mat, vertices=16):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=radius_bottom, radius2=radius_top, depth=depth, location=location)
    obj = bpy.context.object
    obj.name = name
    return assign(obj, mat)


def between(name, start, end, radius, mat, vertices=10):
    a, b = Vector(start), Vector(end)
    delta = b - a
    obj = cylinder(name, (a + b) / 2, radius, delta.length, mat, vertices)
    obj.rotation_mode = "QUATERNION"
    obj.rotation_quaternion = delta.to_track_quat("Z", "Y")
    return obj


def make_star(name, location, outer=0.62, inner=0.29, depth=0.16):
    verts = []
    for y in (-depth / 2, depth / 2):
        for i in range(10):
            angle = math.pi / 2 + i * math.pi / 5
            r = outer if i % 2 == 0 else inner
            verts.append((math.cos(angle) * r, y, math.sin(angle) * r))
    faces = [tuple(range(10)), tuple(range(19, 9, -1))]
    for i in range(10):
        j = (i + 1) % 10
        faces.append((i, j, j + 10, i + 10))
    mesh = bpy.data.meshes.new(name + " mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(MAT["gold"])
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    bevel = obj.modifiers.new("Coin-soft star edges", "BEVEL")
    bevel.width = 0.045
    bevel.segments = 2
    obj.modifiers.new("Star normal polish", "WEIGHTED_NORMAL")
    return obj


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)


def create_harbor():
    # Moonlit water and oversized dock establish the tiny-traveler perspective.
    cube("Quiet harbor water", (0, 2.8, -0.58), (24, 18, 0.42), MAT["sea"])
    cube("Main dock platform", (-0.2, -0.9, -0.18), (17, 7.2, 0.62), MAT["dock"], 0.24)
    cube("Long bridge to lighthouse", (0.55, -1.1, 0.27), (10.6, 2.15, 0.38), MAT["plank"], 0.16)
    for i in range(12):
        x = -4.55 + i * 0.92
        cube(f"Hand-laid bridge plank {i+1:02d}", (x, -1.1, 0.50), (0.78, 2.3, 0.13), MAT["dock"], 0.08)
    for i, x in enumerate((-3.6, -1.8, 0.0, 1.8, 3.55)):
        sphere(f"Warm bridge guide light {i+1}", (x, -1.1, 0.68), (0.16, 0.16, 0.11), MAT["glass"], 12, 8)
        cylinder(f"Brass light rim {i+1}", (x, -1.1, 0.58), 0.23, 0.08, MAT["trim"], 12)

    # Tiny original traveler with a bright coat and a practical lamp backpack.
    px, py = -5.0, -2.0
    cube("Traveler boots", (px, py, 0.67), (0.58, 0.52, 0.25), MAT["dark"], 0.10)
    cube("Traveler coat", (px, py, 1.28), (0.78, 0.56, 1.02), MAT["coat"], 0.20)
    sphere("Traveler head", (px, py - 0.02, 2.10), (0.39, 0.37, 0.43), MAT["skin"])
    cone("Traveler knit cap", (px, py, 2.52), 0.48, 0.06, 0.49, MAT["cap"], 12)
    cylinder("Traveler cap brim", (px, py, 2.31), 0.43, 0.12, MAT["cap"], 12)
    cube("Traveler backpack", (px + 0.48, py + 0.20, 1.42), (0.34, 0.42, 0.58), MAT["pack"], 0.10)
    sphere("Backpack lamp", (px + 0.49, py - 0.04, 1.50), (0.15, 0.11, 0.20), MAT["glass"], 12, 8)
    between("Traveler left arm", (px - 0.32, py, 1.63), (px - 0.60, py - 0.02, 1.06), 0.12, MAT["coat"])
    between("Traveler right arm", (px + 0.32, py, 1.63), (px + 0.55, py - 0.05, 1.16), 0.12, MAT["coat"])

    # Tower silhouette, lantern room, glowing lens and dark arched doorway.
    tx, ty = 5.2, 0.35
    cone("Dream lighthouse tower", (tx, ty, 3.25), 1.45, 0.88, 6.5, MAT["tower"], 12)
    for z, radius in ((1.15, 1.34), (3.0, 1.13), (4.85, 0.98)):
        cylinder(f"Brass tower belt {z:.2f}", (tx, ty, z), radius, 0.12, MAT["trim"], 12)
    cube("Lantern room", (tx, ty, 6.65), (2.28, 1.72, 1.34), MAT["dark"], 0.16)
    for xoff in (-0.78, 0.78):
        cube("Lantern brass frame", (tx + xoff, ty - 0.91, 6.68), (0.11, 0.13, 1.2), MAT["trim"], 0.035)
    cube("Large glowing lighthouse lens", (tx, ty - 0.95, 6.7), (1.35, 0.18, 0.58), MAT["glass"], 0.12)
    cone("Lantern roof", (tx, ty, 7.54), 1.48, 0.0, 0.74, MAT["trim"], 12)
    cylinder("Lantern roof finial", (tx, ty, 8.03), 0.13, 0.28, MAT["gold"], 10)
    cube("Lighthouse doorway", (tx, ty - 1.48, 1.12), (0.82, 0.15, 1.72), MAT["dark"], 0.13)
    sphere("Door latch", (tx, ty - 1.59, 1.04), (0.09, 0.06, 0.09), MAT["gold"], 12, 8)

    # Oversized dream jar and a few decorative star coins along the dock edge.
    cylinder("Oversized dream jar", (0.25, -3.2, 1.12), 0.58, 1.42, MAT["jar"], 16)
    cylinder("Dream jar brass rim", (0.25, -3.2, 1.88), 0.63, 0.14, MAT["trim"], 16)
    cylinder("Dream jar lid", (0.25, -3.2, 2.02), 0.48, 0.15, MAT["dark"], 16)
    for i in range(3):
        cylinder(f"Visible star coin {i+1}", (0.03 + i * 0.2, -3.18, 1.17 + (i % 2) * 0.21), 0.20, 0.07, MAT["gold"], 20, (math.radians(90), 0, 0))
    make_star("Goal star on the bridge", (0.15, -1.45, 2.2), 0.58, 0.27, 0.18)

    # Horizon layers, bollards and ropes frame the playable path.
    for x in (-7.4, -4.0, -0.1, 3.1, 7.0):
        cylinder("Dock bollard", (x, -3.55, 0.47), 0.19, 0.65, MAT["trim"], 10)
        sphere("Bollard cap", (x, -3.55, 0.83), (0.23, 0.23, 0.12), MAT["plank"], 12, 8)
    cube("Far wave silhouette", (0.0, 7.2, 1.05), (25, 0.42, 2.1), MAT["wave"], 0.2)
    cube("Near wave silhouette", (-1.0, 6.0, 0.24), (22, 0.34, 1.0), MAT["dock"], 0.16)


def add_lighting_and_camera():
    world = bpy.data.worlds.new("Deep-blue harbor night") if not bpy.data.worlds else bpy.data.worlds[0]
    bpy.context.scene.world = world
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.025, 0.045, 0.08, 1.0)
    world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.32

    bpy.ops.object.light_add(type="AREA", location=(2.0, -7.0, 11.0))
    key = bpy.context.object
    key.name = "Soft moon key light"
    key.data.energy = 1450
    key.data.shape = "DISK"
    key.data.size = 8.0
    key.data.color = (0.66, 0.77, 1.0)
    key.rotation_euler = (math.radians(28), 0, math.radians(12))

    bpy.ops.object.light_add(type="AREA", location=(5.2, -1.5, 7.0))
    lantern = bpy.context.object
    lantern.name = "Lighthouse amber fill"
    lantern.data.energy = 380
    lantern.data.size = 3.2
    lantern.data.color = (1.0, 0.57, 0.23)
    lantern.rotation_euler = (math.radians(90), 0, 0)

    bpy.ops.object.camera_add(location=(10.8, -18.5, 11.2))
    camera = bpy.context.object
    camera.name = "Harbor diorama camera"
    target = Vector((0.0, -0.1, 2.0))
    camera.rotation_euler = (target - camera.location).to_track_quat("-Z", "Y").to_euler()
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 19.5
    bpy.context.scene.camera = camera


def save_and_export():
    scene = bpy.context.scene
    # Avoid the desktop thumbnail service writing outside the project sandbox.
    bpy.context.preferences.filepaths.file_preview_type = "NONE"
    # Workbench is selected for a portable, material-color viewport when opened.
    scene.render.engine = "BLENDER_WORKBENCH"
    scene.render.resolution_x = 1600
    scene.render.resolution_y = 900
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.filepath = str(ASSETS / "dream_dock_preview.png")
    scene.view_settings.view_transform = "AgX"
    scene.render.film_transparent = False

    # Save the complete editable Blender scene, including its camera and lighting.
    bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE / "dream_dock_environment.blend"))
    # Export only the modeled meshes. Godot supplies its own camera, lights, and UI.
    bpy.ops.object.select_all(action="DESELECT")
    for obj in scene.objects:
        if obj.type == "MESH":
            obj.select_set(True)
    bpy.context.view_layer.objects.active = next((o for o in scene.objects if o.type == "MESH"), None)
    bpy.ops.export_scene.gltf(
        filepath=str(ASSETS / "dream_dock_environment.glb"),
        export_format="GLB",
        use_selection=True,
        export_apply=True,
        export_animations=False,
    )
    print(f"Saved Blender source: {SOURCE / 'dream_dock_environment.blend'}")
    print(f"Exported Godot model: {ASSETS / 'dream_dock_environment.glb'}")


clear_scene()
create_harbor()
add_lighting_and_camera()
save_and_export()
