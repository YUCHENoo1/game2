extends Control

const WORLD_SCENE: PackedScene = preload("res://assets/dream_dock_environment.glb")
const VIEW_SIZE := Vector2i(1600, 900)
const TOTAL_COINS := 8
const SAVING_TARGET := 6
const SAFE_OPTION := 0

var stage := 0
var snack_coins := 4
var attempts := 0
var stage_scores: Array[int] = [0, 0]
var first_try_correct: Array[bool] = [false, false]
var stage_solved := false
var selected_option := -1
var ui_font: Font
var overlay: Control
var feedback_label: Label
var score_label: Label
var key_label: Label
var snack_count_label: Label
var savings_count_label: Label
var puzzle_controls: Array[Control] = []

func _ready() -> void:
	ui_font = _make_ui_font()
	_build_3d_backdrop()
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(overlay)
	_show_intro()

func _make_ui_font() -> Font:
	return load("res://assets/fonts/NotoSansTC-Variable.ttf") as Font

func _build_3d_backdrop() -> void:
	var viewport_container := SubViewportContainer.new()
	viewport_container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	viewport_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	viewport_container.stretch = true
	add_child(viewport_container)

	var viewport := SubViewport.new()
	viewport.size = VIEW_SIZE
	viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
	viewport_container.add_child(viewport)

	var world := Node3D.new()
	world.name = "HarborWorld"
	viewport.add_child(world)

	var environment := WorldEnvironment.new()
	var world_settings := Environment.new()
	world_settings.background_mode = Environment.BG_COLOR
	world_settings.background_color = Color("111b2b")
	world_settings.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	world_settings.ambient_light_color = Color("8697ad")
	world_settings.ambient_light_energy = 0.72
	world_settings.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.environment = world_settings
	world.add_child(environment)

	var camera := Camera3D.new()
	camera.position = Vector3(8.8, 7.2, 11.8)
	camera.look_at(Vector3(0.0, 1.6, 0.0), Vector3.UP)
	camera.fov = 42.0
	world.add_child(camera)
	camera.current = true

	var key_light := DirectionalLight3D.new()
	key_light.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	key_light.light_color = Color("ffe1ad")
	key_light.light_energy = 1.15
	key_light.shadow_enabled = true
	world.add_child(key_light)

	var harbor := WORLD_SCENE.instantiate()
	harbor.name = "BlenderHarbor"
	world.add_child(harbor)

func _clear_overlay() -> void:
	for child in overlay.get_children():
		child.queue_free()
	puzzle_controls.clear()
	feedback_label = null
	score_label = null
	key_label = null
	snack_count_label = null
	savings_count_label = null

func _show_intro() -> void:
	_clear_overlay()
	_add_tint()
	_add_hud_title("夢想碼頭", "小小理財家・兩關夜航挑戰")
	_add_panel(Rect2(170, 214, 1260, 445), Color("18283a"), Color("d6b56e"), 3, 28)
	_add_label("把每一枚星幣，變成靠近夢想的一步。", Rect2(240, 265, 1120, 64), 38, Color("fff0d2"), true)
	_add_label("第一關：分配零用錢，為燈塔目標儲蓄。\n第二關：比較模擬投資的可能報酬與風險，為短期目標做選擇。\n\n每關解題取得一把鑰匙；完成後會看到你的得分與首輪挑戰進度。", Rect2(244, 353, 1100, 190), 25, Color("d9e1e6"))
	_add_label("所有金額和投資選項都是遊戲中的虛構星幣，不涉及真實金融產品。", Rect2(244, 563, 1100, 36), 18, Color("b5c4c7"))
	_add_button("開始冒險", Rect2(590, 690, 420, 82), _start_level_one, Color("d29b50"), Color("172434"), 30)

func _start_level_one() -> void:
	stage = 1
	snack_coins = 4
	attempts = 0
	stage_solved = false
	_show_level_one()

func _show_level_one() -> void:
	_clear_overlay()
	_add_tint()
	_add_hud_title("夢想碼頭", "第 1 關・點亮夢想燈塔")
	_add_hud_status()
	_add_panel(Rect2(48, 620, 1504, 236), Color("172633"), Color("ae9568"), 3, 24)
	_add_label("手上有 8 枚星幣：點心盒放 2 枚，其餘存進夢想罐（目標至少 6 枚）。", Rect2(82, 645, 1435, 45), 27, Color("fff0d2"), true)
	_add_label("點心盒", Rect2(105, 710, 160, 34), 22, Color("d8e1df"))
	var minus := _add_button("−", Rect2(270, 700, 64, 62), _change_snacks.bind(-1), Color("40505a"), Color("ffffff"), 32)
	snack_count_label = _add_label(str(snack_coins), Rect2(344, 704, 72, 54), 32, Color("fff2d8"), true, HORIZONTAL_ALIGNMENT_CENTER)
	var plus := _add_button("+", Rect2(425, 700, 64, 62), _change_snacks.bind(1), Color("40505a"), Color("ffffff"), 32)
	_add_label("夢想罐", Rect2(545, 710, 140, 34), 22, Color("d8e1df"))
	savings_count_label = _add_label("%d / 8" % (TOTAL_COINS - snack_coins), Rect2(695, 704, 145, 54), 30, Color("f6d27d"), true)
	feedback_label = _add_label("用 − / + 調整星幣；夢想罐會自動計算。完成後按「檢查配置」。", Rect2(85, 790, 960, 38), 18, Color("b9c7c8"))
	var check := _add_button("檢查配置", Rect2(1130, 708, 330, 68), _check_level_one, Color("d29b50"), Color("1d2a34"), 26)
	puzzle_controls = [minus, plus, check]
	_update_score_and_key()

func _change_snacks(amount: int) -> void:
	if stage_solved:
		return
	snack_coins = clampi(snack_coins + amount, 0, TOTAL_COINS)
	if snack_count_label:
		snack_count_label.text = str(snack_coins)
	if savings_count_label:
		savings_count_label.text = "%d / 8" % (TOTAL_COINS - snack_coins)

func _check_level_one() -> void:
	if stage_solved:
		return
	attempts += 1
	if snack_coins == 2 and TOTAL_COINS - snack_coins >= SAVING_TARGET:
		_complete_stage(1)
	else:
		if attempts == 1:
			first_try_correct[0] = false
		feedback_label.text = "再想一想：先留出 2 枚點心錢，剩下的 6 枚就能達到儲蓄目標。"
		feedback_label.add_theme_color_override("font_color", Color("ffd594"))

func _show_level_two() -> void:
	_clear_overlay()
	_add_tint()
	_add_hud_title("夢想碼頭", "第 2 關・風浪中的選擇")
	_add_hud_status()
	_add_panel(Rect2(48, 620, 1504, 236), Color("172633"), Color("ae9568"), 3, 24)
	_add_label("明天要用 8 枚星幣修船；現在有 6 枚。哪個模擬方案能確保達成短期目標？", Rect2(82, 642, 1435, 48), 25, Color("fff0d2"), true)
	var safe := _add_button("港灣儲蓄\n穩定增加 2 枚，明天一定有 8 枚。", Rect2(82, 710, 445, 102), _choose_investment.bind(0), Color("344c4c"), Color("e9f1df"), 21)
	var risky := _add_button("風浪種子\n可能增加 5 枚，也可能減少 3 枚。", Rect2(577, 710, 445, 102), _choose_investment.bind(1), Color("405065"), Color("e9f1df"), 21)
	var hold := _add_button("先不投入\n星幣仍是 6 枚，還不夠修船。", Rect2(1072, 710, 445, 102), _choose_investment.bind(2), Color("504448"), Color("f3e4db"), 21)
	feedback_label = _add_label("選一個方案。注意：可能報酬較高，也可能伴隨較大的損失。", Rect2(85, 817, 990, 28), 18, Color("b9c7c8"))
	puzzle_controls = [safe, risky, hold]
	_update_score_and_key()

func _choose_investment(option: int) -> void:
	if stage_solved:
		return
	selected_option = option
	attempts += 1
	if option == SAFE_OPTION:
		_complete_stage(2)
	else:
		if attempts == 1:
			first_try_correct[1] = false
		if option == 1:
			feedback_label.text = "風浪種子的可能報酬較高，但明天也可能少 3 枚；短期目標要先看能否承受損失。"
		else:
			feedback_label.text = "不投入不會有損失，但 6 枚還沒達到修船所需的 8 枚。"
		feedback_label.add_theme_color_override("font_color", Color("ffd594"))

func _complete_stage(level_number: int) -> void:
	stage_solved = true
	var attempt_score := maxi(60, 100 - maxi(attempts - 1, 0) * 10)
	stage_scores[level_number - 1] = attempt_score
	if attempts == 1:
		first_try_correct[level_number - 1] = true
	_add_key_visual(level_number)
	_update_score_and_key()
	if level_number == 1:
		feedback_label.text = "配置正確！橋燈亮起，KEY 1 已取得。準備前往風浪碼頭。"
	else:
		feedback_label.text = "選擇符合明天的修船目標！KEY 2 已取得，出口開啟。"
	feedback_label.add_theme_color_override("font_color", Color("a8e2b7"))
	for control in puzzle_controls:
		control.disabled = true
	if level_number == 1:
		_add_button("前往第 2 關", Rect2(1130, 790, 330, 52), _show_level_two, Color("d29b50"), Color("1d2a34"), 22)
	else:
		_add_button("查看進步成果", Rect2(1130, 790, 330, 52), _show_summary, Color("d29b50"), Color("1d2a34"), 22)

func _show_summary() -> void:
	_clear_overlay()
	_add_tint()
	_add_hud_title("夢想碼頭", "冒險完成・你的理財進步成果")
	_add_panel(Rect2(170, 200, 1260, 500), Color("18283a"), Color("d6b56e"), 3, 28)
	_add_label("兩把 KEY 都已取得！", Rect2(240, 237, 1120, 58), 38, Color("ffe2a0"), true)
	_add_label("第 1 關｜儲蓄目標　%d / 100 分\n第 2 關｜風險與報酬　%d / 100 分\n總分　%d / 200 分" % [stage_scores[0], stage_scores[1], stage_scores[0] + stage_scores[1]], Rect2(245, 322, 500, 150), 27, Color("edf1eb"))
	var first_correct_count := int(first_try_correct[0]) + int(first_try_correct[1])
	var first_rate := first_correct_count * 50
	_add_panel(Rect2(790, 315, 545, 168), Color("263b4b"), Color("8b9c95"), 2, 20)
	_add_label("首輪挑戰答對\n%d / 2 關（%d%%）" % [first_correct_count, first_rate], Rect2(830, 340, 460, 115), 28, Color("e2ece5"), true, HORIZONTAL_ALIGNMENT_CENTER)
	_add_label("你完成了 2 / 2 關，取得 2 把 KEY。\n\n學到的策略：先分配預算、為目標儲蓄；比較投資方案時，同時留意可能報酬、可能損失和目標期限。\n\n「風浪種子」是虛構情境；這次成績反映遊戲解題表現，不等同於正式學習測驗。", Rect2(245, 505, 1100, 145), 21, Color("cbd7d7"))
	_add_button("再玩一次", Rect2(590, 735, 420, 72), _restart_game, Color("d29b50"), Color("172434"), 27)

func _restart_game() -> void:
	stage_scores = [0, 0]
	first_try_correct = [false, false]
	selected_option = -1
	_show_intro()

func _update_score_and_key() -> void:
	if score_label:
		score_label.queue_free()
	if key_label:
		key_label.queue_free()
	score_label = _add_label("關卡分數　%d" % (stage_scores[stage - 1] if stage > 0 and stage <= 2 else 0), Rect2(1260, 34, 290, 54), 24, Color("fff0d2"), true, HORIZONTAL_ALIGNMENT_RIGHT)
	var visible_keys := 0
	if stage == 1 and stage_solved:
		visible_keys = 1
	elif stage == 2:
		visible_keys = 2 if stage_solved else 1
	key_label = _add_label("KEY %d / 2" % visible_keys, Rect2(1270, 95, 280, 42), 21, Color("f5d17a"), true, HORIZONTAL_ALIGNMENT_RIGHT)

func _add_key_visual(level_number: int) -> void:
	var x_position := 1000.0 + float(level_number - 1) * 150.0
	_add_panel(Rect2(x_position, 505, 132, 48), Color("263b3b"), Color("f2cb73"), 2, 18)
	_add_label("KEY %d" % level_number, Rect2(x_position + 8, 509, 116, 40), 20, Color("ffe09a"), true, HORIZONTAL_ALIGNMENT_CENTER)

func _add_tint() -> void:
	var tint := ColorRect.new()
	tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tint.color = Color(0.025, 0.045, 0.075, 0.24)
	tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(tint)

func _add_hud_title(title: String, subtitle: String) -> void:
	_add_panel(Rect2(48, 32, 520, 112), Color(0.04, 0.075, 0.12, 0.88), Color(0.5, 0.57, 0.6, 0.48), 2, 20)
	_add_label(title, Rect2(80, 48, 440, 48), 33, Color("fff0d2"), true)
	_add_label(subtitle, Rect2(82, 96, 440, 34), 21, Color("c7d3d4"))

func _add_hud_status() -> void:
	_add_panel(Rect2(1238, 27, 314, 122), Color(0.04, 0.075, 0.12, 0.88), Color("d1ae69"), 2, 18)
	_update_score_and_key()

func _add_panel(rect: Rect2, fill: Color, border: Color, border_width: int, radius: int) -> Panel:
	var panel := Panel.new()
	panel.position = rect.position
	panel.size = rect.size
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(border_width)
	style.set_corner_radius_all(radius)
	style.shadow_color = Color(0, 0, 0, 0.28)
	style.shadow_size = 8
	panel.add_theme_stylebox_override("panel", style)
	overlay.add_child(panel)
	return panel

func _add_label(text: String, rect: Rect2, font_size: int, color: Color, bold: bool = false, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var label := Label.new()
	label.text = text
	label.position = rect.position
	label.size = rect.size
	label.add_theme_font_override("font", ui_font)
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.horizontal_alignment = align
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if bold:
		label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.28))
		label.add_theme_constant_override("outline_size", 1)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(label)
	return label

func _add_button(text: String, rect: Rect2, action: Callable, fill: Color, text_color: Color, font_size: int) -> Button:
	var button := Button.new()
	button.text = text
	button.position = rect.position
	button.size = rect.size
	button.add_theme_font_override("font", ui_font)
	button.add_theme_font_size_override("font_size", font_size)
	button.add_theme_color_override("font_color", text_color)
	button.add_theme_color_override("font_hover_color", text_color)
	button.add_theme_color_override("font_pressed_color", text_color)
	button.add_theme_color_override("font_focus_color", text_color)
	button.add_theme_stylebox_override("normal", _button_style(fill, Color("d5b16c")))
	button.add_theme_stylebox_override("hover", _button_style(fill.lightened(0.12), Color("ffe19a")))
	button.add_theme_stylebox_override("pressed", _button_style(fill.darkened(0.12), Color("ffe19a")))
	button.add_theme_stylebox_override("focus", _button_style(fill, Color("fff0c1")))
	button.add_theme_stylebox_override("disabled", _button_style(fill.darkened(0.18), Color("768080")))
	button.add_theme_constant_override("outline_size", 1)
	button.focus_mode = Control.FOCUS_ALL
	button.pressed.connect(action)
	overlay.add_child(button)
	return button

func _button_style(fill: Color, border: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(2)
	style.set_corner_radius_all(17)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style
